
Daten für eine Sentimentanalyse
